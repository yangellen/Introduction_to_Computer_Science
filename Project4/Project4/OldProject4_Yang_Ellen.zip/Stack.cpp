/*******************************************************************************
**  Ellen Yang
**  Stack.cpp
**  11/14/18.
**  Stack.cpp is the Stack class function implementation file, which add the
**  loser to the top of stack and print the loser in reverse order.
*****************************************************************************/

#include "Stack.hpp"
#include "iostream"

using std::cout;
using std::endl;

/***************************************************************************
 ** Stack::Stack()
 ** default constactor which create memory for StackNode and set top to nullptr
****************************************************************************/
Stack::Stack()
{
   top = new StackNode;
   top = nullptr;
}

/***************************************************************************
 ** Stack::~Stack()
 ** destactor which delete player and StackNode at the end.
 ****************************************************************************/
Stack::~Stack()
{
   StackNode *temp = top; //start at the top of stack

   while (temp != nullptr)
   {
      //garbage keeps track of node to be deleted
      StackNode *garbage = temp;

      //move on to the next node
      temp = temp->next;

      //
      delete temp->player;

      //delete garbage node
      delete garbage;

      cout <<"stack destructor"<<endl; 
   }
}

/******************************************************************************
 ** Void Stack::addTop(Character *character)
 ** This function add loser character to the top of stack
 *************************************************************************/
void Stack::addTop(Character *character)
{
   StackNode *temp = new StackNode();
   temp ->player = character;

   if (top == nullptr)
   {
      top = temp; // top is temp
   }
   else //list is not empty
   {
      top->prev = temp; //add temp to the current top
      temp->next = top;
      top = temp;
   }
}

/*****************************************************************************
** void Stack::printStack()
** This function print the loser from top to bottom
*****************************************************************************/
void Stack::printStack()
{
   StackNode *temp = top;

   if (top == nullptr)
   {
      cout <<"There are no losers !"<<endl;
   }

   else
   {
      cout <<endl; 
      cout <<"Here are the losers: "<<endl;

      while (temp != nullptr)
      {
         cout <<temp->player->getPlayerType()<<" ";
         cout <<temp->player->getName() <<endl;
         temp = temp->next; 
      }
      cout <<endl;

   }
}



